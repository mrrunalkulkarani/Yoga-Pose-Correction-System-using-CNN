  let video;
let pose;
let skeleton;
let pose_names = ["MOUNTAIN", "SUKHASANA", "PRAYER", "WARRIOR"];
let angles;
let posesDropdown;
let msgSpan;
let tts_msg;
let selected_pose;
let poseNet;
let flag=0;
function setup() {
  createCanvas(640, 480);
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  // create options of poses in dropdown
  posesDropdown = document.getElementById("poses_dropdown");
  msgSpan = document.getElementById("message");
  
  // text to speech setup check
  if ("speechSynthesis" in window) {
    // Speech Synthesis supported 🎉
    tts_msg = new SpeechSynthesisUtterance();
    alert("Text to Speech setup complete!");
    console.log(speechSynthesis.getVoices());
    voices = speechSynthesis.getVoices();
    if (voices.length){ // set voice to Heera if available
      tts_msg.voice = voices[2]; // Microsoft Heera
      alert(tts_msg.voice);
    }
  } else {
    // Speech Synthesis Not Supported 😣
    alert("Sorry, your browser doesn't support text to speech!");
  }

  pose_names.forEach((name) => {
    posesDropdown.options[posesDropdown.options.length] = new Option(
      name,
      name
    );
  });

  tts_msg.text = "Select your pose from the dropdown menu";
  window.speechSynthesis.speak(tts_msg); 

  selected_pose = posesDropdown.value;

  // setup posenet model
  // posenet requires input image/video and a callback function
  poseNet = ml5.poseNet(video, modelLoaded);

  // on() function is called on seeing a pose.
  // the object of bodypoints is given to callback function getPoses
  setInterval(() => {
    poseNet.on("pose", getPoses);
  }, 3000);

  // getPoses initializes pose and skeleton variables
}

// call back function
function modelLoaded() {
  console.log("PoseNet model loaded!");
  correction();

}


function display(msg) {
  msgSpan.innerHTML = msg;
  tts_msg.text = msg;
  window.speechSynthesis.speak(tts_msg); 
}

function in_range(low, val, high) {
  if (val > low && val < high) {
    return 0;
  } else if (val < low) {
    return -1;
  } else if (val > high) {
    return 1;
  }
}

function correction(params) {
  if (pose) {
    const poseArray = pose.keypoints.map((p) => [
      p.score,
      p.position.x,
      p.position.y,
    ]);
    setInterval(() => {
      // console.log(angles);
      if (selected_pose != "none") { // if a pose is selected then only correct
        let leftKHH_range,
          rightKHH_range,
          leftWEH_range,
          rightWEH_range,
          leftWES_range,
          rightWES_range,
          leftESH_range,
          rightESH_range,
          leftAKH_range,
          rightAKH_range,
          leftSEW_range,
          rightSEW_range;

        switch (selected_pose) {
          case "MOUNTAIN":
            console.log("angles.left.KHH"+ angles.left.KHH)
            console.log("angles.right.KHH"+ angles.right.KHH)
            console.log("angles.left.WEH"+ angles.left.WEH)
            console.log("angles.right.WEH"+ angles.right.WEH)
            leftKHH_range = in_range(70, angles.left.KHH, 95);
            rightKHH_range = in_range(60, angles.right.KHH, 90);
            leftWEH_range = in_range(25, angles.left.WEH, 45);
            rightWEH_range = in_range(25, angles.right.WEH, 45);

            if (leftKHH_range == -1 || rightKHH_range == -1) {
              display("Join your both legs");
            } else if (leftWEH_range == -1 || rightWEH_range == -1) {
              display("Spread your arms a little bit");
            } else if ((leftKHH_range == 0 || rightKHH_range == 0) && (leftWEH_range == 0 || rightWEH_range == 0)) {
              display("Mountain Pose Correct");
            } 
            break;

            case "SUKHASANA":
              leftAKH_range = in_range(45, angles.left.AKH, 80);
              rightAKH_range = in_range(90, angles.right.AKH, 120);
              leftESH_range = in_range(15, angles.left.ESH, 30);
              rightESH_range = in_range(10, angles.right.ESH, 20);
              leftSEW_range = in_range(140, angles.left.SEW, 170);
              rightSEW_range = in_range(140, angles.right.SEW, 170);
              console.log("leftAKH_range"+ angles.left.AKH)
                        console.log("rightAKH_range"+ angles.right.AKH)
                        console.log("leftESH_range"+ angles.left.ESH)
                        console.log("leftSEW_range"+ angles.right.ESH)
                        console.log("leftSEW_range"+ angles.left.SEW)
                        console.log("rightSEW_range"+ angles.right.SEW)
                        console.log("leftAKH_range"+ leftAKH_range)
                        console.log("rightAKH_range"+ rightAKH_range)
                        console.log("leftESH_range"+ leftESH_range)
                        console.log("leftSEW_range"+ rightESH_range)
                        console.log("leftSEW_range"+ leftSEW_range)
                        console.log("rightSEW_range"+ rightSEW_range)
                        console.log("---------------------------------------")
                      
              if (
                leftAKH_range == 0 &&
                leftESH_range == 0 &&
                rightESH_range == 0 &&
              
                rightSEW_range == 0 &&
                rightAKH_range == -1
              ) {
                display("Sukhasana Pose Correct");
              } else {
                if (leftAKH_range !== 1 ) {
                  display("Bend your knees comfortably");
                } else if (leftESH_range !== 0 || rightESH_range !== 0) {
                  display("Sit upright with straight spine");
                } else if (leftSEW_range !== 0 || rightSEW_range !== 0) {
                  display("Relax your arms on your knees");
                }
              }
              break;

          case "PRAYER":
  let standing_leg_AKH = angles.right.AKH;
  let raised_leg_AKH = angles.left.AKH;

  leftWES_range = in_range(15, angles.left.WES, 45);
  rightWES_range = in_range(15, angles.right.WES, 45);
  leftSEW_range = in_range(10, angles.left.SEW, 35);
  rightSEW_range = in_range(10, angles.right.SEW, 35);

  let is_leg_balanced = in_range(170, standing_leg_AKH, 180);
  let is_leg_raised = in_range(110, raised_leg_AKH, 130); // bent leg
  console.log("angles.left.WES"+ angles.left.WES)
  console.log("angles.right.WES"+ angles.right.WES)
  console.log("angles.right.SEW"+ angles.right.SEW)
  console.log("angles.left.SEW"+ angles.left.SEW)
  
  console.log("angles.right.AKH"+ angles.right.AKH)
  console.log("angles.right.AKH"+ angles.left.AKH)
  if (is_leg_balanced !== 0) {
   if(flag==0)
    display("Keep your standing leg straight");
  }  else if (leftWES_range !== 0 || rightWES_range !== 0) {
    if(flag==0)
    display("Bend your arms so your palms are together");
  } else if (leftSEW_range !== 0 || rightSEW_range !== 0) {
    if(flag==0)
    display("Bring your hands closer to your chest in prayer");
  } else {
    flag =1;
    display("ONE LEG PRAYER Pose Correct");
  }
            break;

          case "WARRIOR":


            leftAKH_range = in_range(80, angles.left.AKH, 100);
            rightAKH_range = in_range(80, angles.right.AKH, 100);
            leftESH_range = in_range(80, angles.left.ESH, 100);
            rightESH_range = in_range(80, angles.right.ESH, 100);
            leftSEW_range = in_range(160, angles.left.SEW, 180);
            rightSEW_range = in_range(160, angles.right.SEW, 180);

            console.log("leftAKH_range"+ leftAKH_range)
            console.log("rightAKH_range"+ rightAKH_range)
            console.log("leftESH_range"+ leftESH_range)
            console.log("leftSEW_range"+ leftSEW_range)
            console.log("leftSEW_range"+ leftSEW_range)
            console.log("rightSEW_range"+ rightSEW_range)
            console.log("---------------------------------------")
            if (
              leftSEW_range == -1 &&
              rightSEW_range == -1 &&
              leftESH_range == -1 &&
              rightSEW_range == -1 && leftAKH_range ==1 && rightAKH_range==1
            ) {
              display("Spread your legs and arm");
            }
            else if (
              leftSEW_range == -1 &&
              rightSEW_range == -1 &&
              leftESH_range == 0 &&
              rightSEW_range == -1 && leftAKH_range ==1 && rightAKH_range==1
            ) {
              display("Warrior Pose Correct");
            } else if (
              leftSEW_range == 0 &&
              rightSEW_range == 0 &&
              leftESH_range == 0 &&
              rightSEW_range == 0 && leftAKH_range ==1 && rightAKH_range==1
            ) {
              display("Warrior Pose Correct");
            }
            break;
        }
      }
    }, 500); // correction after every 0.5 sec
  } else {
    setTimeout(correction, 1000);
  }
}

function getPoses(poses) {
  if (poses.length > 0) {
    pose = poses[0].pose;
    skeleton = poses[0].skeleton;

    setInterval(() => {
      calculateAngles(pose);
    }, 3000); // calculate angles every 3 seconds
  }
}

/*
 * Calculates the angle ABC (in radians)
 *
 * A first point, ex: {x: 0, y: 0}
 * C second point
 * B center point
 */

function angle(A, B, C) {
  let AB = Math.sqrt(Math.pow(B.x - A.x, 2) + Math.pow(B.y - A.y, 2));
  let BC = Math.sqrt(Math.pow(B.x - C.x, 2) + Math.pow(B.y - C.y, 2));
  let AC = Math.sqrt(Math.pow(C.x - A.x, 2) + Math.pow(C.y - A.y, 2));
  ans =
    (Math.acos((BC * BC + AB * AB - AC * AC) / (2 * BC * AB)) * 180) / Math.PI;
  return Math.round(ans * 100) / 100;
}

function calculateAngles(pose) {
  let ankle = [pose.leftAnkle, pose.rightAnkle];
  let knee = [pose.leftKnee, pose.rightKnee];
  let hip = [pose.leftHip, pose.rightHip];
  let elbow = [pose.leftElbow, pose.rightElbow];
  let shoulder = [pose.leftShoulder, pose.rightShoulder];
  let wrist = [pose.leftWrist, pose.rightWrist];

  angles = {
    left: {
      KHH: angle(knee[0], hip[0], hip[1]), // left knee left hip right hip
      WEH: angle(wrist[0], elbow[0], hip[0]), // wrist elbow hip
      WES: angle(wrist[0], elbow[0], shoulder[0]), // wrist elbow shoulder
      AKH: angle(ankle[0], knee[0], hip[0]), // ankle knee hip
      ESH: angle(elbow[0], shoulder[0], hip[0]), // elbow shoulder hip
      SEW: angle(shoulder[0], elbow[0], wrist[0]), // shoulder elbow wrist
    },
    right: {
      KHH: angle(knee[1], hip[1], hip[0]), // right knee right hip left hip
      WEH: angle(wrist[1], elbow[1], hip[1]), // wrist elbow hip
      WES: angle(wrist[1], elbow[1], shoulder[1]), // wrist elbow shoulder
      AKH: angle(ankle[1], knee[1], hip[1]), // ankle knee hip
      ESH: angle(elbow[1], shoulder[1], hip[1]), // elbow shoulder hip
      SEW: angle(shoulder[1], elbow[1], wrist[1]), // shoulder elbow wrist
    },
  };
}

function drawKeypoints() {
  if (pose) {
    for (let j = 0; j < pose.keypoints.length; j++) {
      // A keypoint is an object describing a body part (like rightArm or leftShoulder)
      let keypoint = pose.keypoints[j];
      // Only draw an ellipse is the pose probability is bigger than 0.2
      if (keypoint.score > 0.2) {
        fill(255, 0, 0);
        noStroke();
        ellipse(keypoint.position.x, keypoint.position.y, 10, 10);
      }
    }
  }
}

// A function to draw the skeletons
function drawSkeleton() {
  // Loop through all the skeletons detected
  // let skeleton = poses[i].skeleton;
  // For every skeleton, loop through all body connections
  if (pose) {
    for (let j = 0; j < skeleton.length; j++) {
      let partA = skeleton[j][0];
      let partB = skeleton[j][1];
      stroke(255, 0, 0);
      line(
        partA.position.x,
        partA.position.y,
        partB.position.x,
        partB.position.y
      );
    }
  }
}

function draw() {
  if (selected_pose != "none") {
    image(video, 0, 0, width, height);

    // We can call both functions to draw all keypoints and the skeletons
    drawKeypoints();
    drawSkeleton();
  }
  selected_pose = posesDropdown.value;
}
